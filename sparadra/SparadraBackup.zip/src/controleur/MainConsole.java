package controleur;

import exception.SaisieException;
<<<<<<< HEAD
import vue.Menu2;
=======
import vue.Menu;
>>>>>>> 62f1c7cc4a64e9d329de411c048c153384b42aeb

public class MainConsole {
    public static void main(String[] args) {
        try {
<<<<<<< HEAD
            Menu2.lancerApplication();
            Main.chargement();
            Menu2.menuPrincipal();
=======
            Menu.lancerApplication();
            Main.chargement();
            Menu.menuPrincipal();
>>>>>>> 62f1c7cc4a64e9d329de411c048c153384b42aeb

            }catch (SaisieException e){
            System.err.println("il y a comme un probleme : "+e.getMessage());
        }

    }

}
