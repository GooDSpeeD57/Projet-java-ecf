package exception;

public class SaisieException extends Exception {
    public SaisieException()
    {
        super();
    }
    public SaisieException(String message) {
        super(message);
    }
}
