package modele;

import java.io.Serializable;

public class Facturation implements Serializable {
}
